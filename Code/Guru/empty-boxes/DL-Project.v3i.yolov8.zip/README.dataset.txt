# DL-Project > 2024-10-07 5:01am
https://universe.roboflow.com/dlproject-dghzx/dl-project-60wg2

Provided by a Roboflow user
License: CC BY 4.0

