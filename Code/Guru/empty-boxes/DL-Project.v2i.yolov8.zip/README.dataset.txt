# DL-Project > 2024-10-06 7:25pm
https://universe.roboflow.com/dlproject-dghzx/dl-project-60wg2

Provided by a Roboflow user
License: CC BY 4.0

